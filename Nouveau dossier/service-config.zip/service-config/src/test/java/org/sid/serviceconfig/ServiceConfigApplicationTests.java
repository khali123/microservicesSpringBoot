package org.sid.serviceconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
