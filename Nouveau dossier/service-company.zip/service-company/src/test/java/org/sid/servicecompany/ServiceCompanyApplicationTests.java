package org.sid.servicecompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
