package org.sid.proxyservice.proxyservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProxyServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProxyServicesApplication.class, args);
	}

}
