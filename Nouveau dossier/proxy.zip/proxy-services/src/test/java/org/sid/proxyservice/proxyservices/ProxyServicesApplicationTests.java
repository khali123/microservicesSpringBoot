package org.sid.proxyservice.proxyservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
